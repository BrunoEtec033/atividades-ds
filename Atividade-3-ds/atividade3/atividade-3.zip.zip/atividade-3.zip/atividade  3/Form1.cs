namespace atividade__3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Add(txt_titulo.Text, txt_genero.Text, txt_duracao.Text);
            MessageBox.Show("Cadastro Feito Com Sucesso");


            txt_titulo.Clear();
            txt_genero.Clear();
            txt_duracao.Clear();


            txt_titulo.Focus();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }
    }
}
